/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.cuyocorp.DAO;

import mx.cuyocorp.entidad.Unidadaprendizaje;
import mx.cuyocorp.persistencia.AbstractDAO;

/**
 *
 * @author total
 */
public class UnidadAprendizajeDAO extends AbstractDAO<Integer, Unidadaprendizaje>{
    
}
