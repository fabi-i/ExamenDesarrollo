/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.cuyocorp.DAO;

import mx.cuyocorp.entidad.Profesor;
import mx.cuyocorp.persistencia.AbstractDAO;

/**
 *
 * @author total
 */
public class ProfesorDAO extends AbstractDAO<Integer, Profesor>{
    
}
